import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {  
  Name: string =  localStorage.getItem("StudentUserName");
  StudentToken: string = localStorage.getItem("TokenValue");
  userName: string = localStorage.getItem("userName");
  Claims: string = localStorage.getItem("Claims");
  Id: string = localStorage.getItem("Id");
  PhoneNumber: string = localStorage.getItem("PhoneNumber");
  constructor() {
    
   }

  ngOnInit() {

  }

}
