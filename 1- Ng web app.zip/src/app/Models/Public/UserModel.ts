export interface User {
    id: number;
    Userid: string;
    Name: string;
    Username: string;
    EmailID: string;
    Password:string;
    PhoneNo: string;
    Createdon: string;
    isActive: boolean;
}