import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-menu',
  templateUrl: './common-menu.component.html',
  styleUrls: ['./common-menu.component.css']
})
export class CommonMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
