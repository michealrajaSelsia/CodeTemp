import { Component, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import {UserService} from '../../Services/public-api.service';
import {GalleryImage} from '../../Models/Public/GalleryImageModel'

@Component({
  selector: 'app-galary',
  templateUrl: './galary.component.html',
  styleUrls: ['./galary.component.css']
})
export class GalaryComponent implements OnInit {

  public gallary: GalleryImage[];
  isGalleryData=true;

  imageCollection: Array<GalleryImage>;
  
  constructor(private myser :UserService ) { }

  ngOnInit() {    
    this. getDataFromServer1();    
    setTimeout(function(){
      this.isGalleryData=true;   
    },5000)
  }

  public getDataFromServer1() {

    this.myser.getGalleryImages1().subscribe((gallaries)=>this.gallary = gallaries)  


    
  }

  public getDataFromServer()
  {
   
    this.myser.getGalleryImages().subscribe(
      (response: Response) =>
      {
        this.imageCollection= response.json();
        console.log(this.imageCollection);
        
      }
    );
    return this.imageCollection;
  }
}
