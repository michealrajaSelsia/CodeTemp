import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormControlName} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { MaterialAppModule} from '../../MainConfig/ngmaterial.module';
import { Router} from '@angular/router';
import { Http} from '@angular/http';
import { UserService} from '../../Services/public-api.service';
import {AdminLoginM} from '../../Models/Public/AdminLoginModel';
import { Response } from '@angular/http';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  objAdModel:AdminLoginM;
  errorMsg:string;
  AdminLoginForm=new FormGroup({
    Username:new FormControl(''),
    Password:new FormControl('')
  });
  constructor( private route:Router, private http:Http, private myApiService:UserService) { }
  ngOnInit() {
   
  }

  onLoginSubmit() {

    this.objAdModel= Object.assign({},this.AdminLoginForm.value);
    this.myApiService.validateAdmin(this.objAdModel).subscribe(
      data => {
        if(data)
         {
           localStorage.setItem("Username",this.objAdModel.Username);
           localStorage.setItem("UserDetails",data.toString());
           localStorage.setItem("TokenValue",data.toString());
           this.route.navigate(["MyAdminHome"])
         }
         else
         {
          this.errorMsg='Enter valid username and password.'
         }
      },
      error => {
        console.log("Error", error);
      }
    )
  }
  
}
