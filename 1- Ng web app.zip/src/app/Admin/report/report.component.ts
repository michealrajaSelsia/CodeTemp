import { Component, OnInit } from '@angular/core';
import{ UserService } from '../../Services/public-api.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  imageUrl:string='/assets/Images/b1.jpg';
  fileToUpload:File=null;
  constructor(private userApi: UserService) { }

  ngOnInit() {
  }

handleFileInput(file:FileList){
  this.fileToUpload=file.item(0);
  var reader=new FileReader();
  reader.onload=(event:any)=>{
    this.imageUrl=event.target.result;
  }
  reader.readAsDataURL(this.fileToUpload);
}

OnSubmit(Caption,Image){
  this.userApi.postFile(Caption.value,this.fileToUpload).subscribe(
    data=>{
      console.log("done");
      Caption.value=null;
      Image.value=null;
    }
  );
}
}
