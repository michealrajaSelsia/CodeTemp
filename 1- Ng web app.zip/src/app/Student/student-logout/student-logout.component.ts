import { Component, OnInit } from '@angular/core';
import {Router } from '@angular/router'
@Component({
  selector: 'app-student-logout',
  templateUrl: './student-logout.component.html',
  styleUrls: ['./student-logout.component.css']
})
export class StudentLogoutComponent implements OnInit {
  constructor( private route:Router) { }
  ngOnInit() {
    alert('Logout Successfully');
    localStorage.removeItem("StudentUserName");
    localStorage.removeItem("TokenValue");
    localStorage.removeItem("userName");
    localStorage.removeItem("Claims");
    localStorage.removeItem("Id");
    localStorage.removeItem("PhoneNumber");
    this.route.navigate(["Home"])
  }
}
