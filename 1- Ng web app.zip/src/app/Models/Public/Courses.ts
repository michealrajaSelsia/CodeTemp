export class Course
{
    ID:number;
    CourseCode:string;
    CourseName:string;
    Description:string;
    isActive:string;
}