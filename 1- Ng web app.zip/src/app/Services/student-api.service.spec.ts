import { TestBed } from '@angular/core/testing';

import { StudentAPIService } from './student-api.service';

describe('StudentAPIService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StudentAPIService = TestBed.get(StudentAPIService);
    expect(service).toBeTruthy();
  });
});
