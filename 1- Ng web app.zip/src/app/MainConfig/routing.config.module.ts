import {NgModule} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from '../app.component';
import { HomeComponent } from '../Public/home/home.component';
import { AboutusComponent } from '../Public/aboutus/aboutus.component';
import { HistoryComponent } from '../Public/history/history.component';
import { ContactusComponent } from '../Public/contactus/contactus.component';
import { GalaryComponent } from '../Public/galary/galary.component';
import { RegistrationComponent } from '../Student/registration/registration.component';
import { EditapplicationComponent } from '../Student/editapplication/editapplication.component';
import { ApplicationStatusComponent } from '../Student/application-status/application-status.component';
import { StudentHomeComponent } from '../Student/student-home/student-home.component';
import { AdminloginComponent } from '../Admin/adminlogin/adminlogin.component';
import { ReportComponent } from '../Admin/report/report.component';
import { ApproveApplicationComponent } from '../Admin/approve-application/approve-application.component';
import { AdminDashBoardComponent } from '../Admin/admin-dash-board/admin-dash-board.component';
import { MyProfileComponent } from '../Student/my-profile/my-profile.component';

import { AdminmenuComponent } from '../Admin/adminmenu/adminmenu.component';
import { StudentmenuComponent } from '../Student/studentmenu/studentmenu.component';
import { CommonMenuComponent } from '../Shared/common-menu/common-menu.component';
import { LayoutComponent } from '../Shared/layout/layout.component';
import { StudentloginComponent } from '../Student//studentlogin/studentlogin.component';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import { MaterialAppModule } from '../MainConfig/ngmaterial.module';
import { ForgetPasswordComponent } from '../Shared/forget-password/forget-password.component';
import {ErrorPageComponent} from '../Shared/error-page/error-page.component';
 import {AuthGuard} from '../auth.guard';
 import { HttpClientModule } from '@angular/common/http';
 import { HttpClient }   from '@angular/common/http';
 import {AdminHomeComponent} from '../Admin/admin-home/admin-home.component';
 import { LogoutComponent} from '../Admin/logout/logout.component';
 import {StudentDashBoardComponent} from '../Student/student-dash-board/student-dash-board.component';
 import { StudentReportComponent} from '../Student/student-report/student-report.component';
 import { PayfeesComponent} from '../Student/payfees/payfees.component';

 import{StudentLogoutComponent} from '../Student/student-logout/student-logout.component';
const routes: Routes = [
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: HomeComponent, },
    { path: 'Aboutus', component: AboutusComponent },
    { path: 'Contactus', component: ContactusComponent },
    { path: 'Galary', component: GalaryComponent },
    { path: 'History', component: HistoryComponent },
    { path: 'Registration', component: RegistrationComponent },
    { path: 'Adminlogin', component: AdminloginComponent },
    { path: 'Studentlogin', component: StudentloginComponent },
    { path: 'ForgetPassword', component: ForgetPasswordComponent }, 
    { path: 'MyAdminHome', component: AdminDashBoardComponent,children:
        [    
            {path:'',component:AdminHomeComponent},      
            {path:'AdminHome',component:AdminHomeComponent},      
            {path:'Report',component:ReportComponent},
            {path:'Approve',component:ApproveApplicationComponent},
            {path:'Application',component:EditapplicationComponent},  
            {path:'AddCourse',component:EditapplicationComponent}, 
            {path:'AddMarks',component:EditapplicationComponent}, 
            {path:'Logout',component:LogoutComponent}     
        ],canActivate:[AuthGuard]   
    },
    { path: 'StudentHome', component: StudentHomeComponent,children:
        [    
            {path:'',component:MyProfileComponent} ,           
            {path:'Application',component:EditapplicationComponent},
            {path:'PayFees',component:PayfeesComponent},
            {path:'Report',component:StudentReportComponent}, 
            {path:'ApplicationStatus',component:PayfeesComponent},
            {path:'StudentComplaint',component:StudentReportComponent}, 
            {path:'Galary',component:PayfeesComponent},
            {path:'Logout',component:StudentLogoutComponent}, 
        ],canActivate:[AuthGuard] 
    },
    { path: 'MyProfile', component: StudentHomeComponent }, 
    { path: '**', component: ErrorPageComponent }
  ];
  

@NgModule({
    imports:[ RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class UniverSityCroutingConfigModule{}



