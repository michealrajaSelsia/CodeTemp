import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-complaint',
  templateUrl: './student-complaint.component.html',
  styleUrls: ['./student-complaint.component.css']
})
export class StudentComplaintComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
