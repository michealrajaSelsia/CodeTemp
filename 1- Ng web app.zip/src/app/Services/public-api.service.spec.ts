// import { TestBed } from '@angular/core/testing';

// import { UserService } from './public-api.service';

// describe('PublicAPIService', () => {
//   beforeEach(() => TestBed.configureTestingModule({}));

//   it('should be created', () => {
//     const service: UserService = TestBed.get(UserService);
//     expect(service).toBeTruthy();
//   });
// });
