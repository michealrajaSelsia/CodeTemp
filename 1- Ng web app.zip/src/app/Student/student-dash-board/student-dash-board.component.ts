import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-dash-board',
  templateUrl: './student-dash-board.component.html',
  styleUrls: ['./student-dash-board.component.css']
})
export class StudentDashBoardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
